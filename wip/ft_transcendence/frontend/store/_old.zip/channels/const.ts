import { namespace } from 'vuex-class'

export const channelsModule = namespace('channels/')
