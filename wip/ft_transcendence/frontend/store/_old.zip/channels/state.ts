import { ChannelsState } from './types'

export const initState = (): ChannelsState => ({
  channels: [],
})

export default initState
