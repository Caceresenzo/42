import { ActionTree, ActionContext, MutationTree, GetterTree } from 'vuex'
import { RootState } from '../types'
import { Channel, ChannelMessage } from '~/models'

export interface ChannelsState {
  channels: Channel[]
}

export type ChannelActionContext = ActionContext<ChannelsState, RootState>

export interface ChannelsActions extends ActionTree<ChannelsState, RootState> {
  fetchAll: (ctx: ChannelActionContext) => void
  sendMessage: (ctx: ChannelActionContext, message: ChannelMessage) => void
}

export interface ChannelsMutations extends MutationTree<ChannelsState> {
  setChannels: (state: ChannelsState, Channels: Channel[]) => void
}

export type ChannelsGetters = GetterTree<ChannelsState, RootState>
