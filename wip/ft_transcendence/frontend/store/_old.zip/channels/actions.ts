import axio from "axios"
import "vuex"

import { Store } from 'vuex'
import { ChannelsActions } from './types'

import { Channel } from '~/models'

declare module 'vue/types/vue' {
  interface Vue {
    $store: Store<any>
  }
}

export const actions: ChannelsActions = {
  async fetchAll({ commit }) {
    try {
      /*const response: any = await this.$axios.get('/channels')
      const channels: Channel[] = response.data

      commit('setChannels', channels)*/
    } catch (error) {}
  },

  sendMessage(_, __) {},
}

export default actions
