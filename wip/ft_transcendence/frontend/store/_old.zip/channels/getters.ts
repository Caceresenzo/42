import { ChannelsGetters } from './types'

export const getters: ChannelsGetters = {}

export default getters
