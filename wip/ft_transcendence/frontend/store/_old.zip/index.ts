import { Store, ActionTree, ActionContext } from 'vuex'

export const state = () => ({
  hello: 'world',
})

export type RootState = ReturnType<typeof state>

export type UserActionContext = ActionContext<RootState, RootState>

export interface UsersActions extends ActionTree<RootState, RootState> {
  // with specified 'this' type (work fine)
  fetchAll(this: Store<RootState>, context: UserActionContext): Promise<void>

  // without specified 'this' type (do not work)
  second(context: UserActionContext): Promise<void>
}

export const actions: UsersActions = {
  async fetchAll(context) {
    await this.$axios.$get('/users')

    console.log(this.constructor.name)
  },

  async second(context) {
    await this.$axios.$get('/users')

    console.log(this.constructor.name)
  },
}
