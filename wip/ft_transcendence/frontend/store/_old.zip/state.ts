const state = () => ({
  drawer: true,
})

export default state
export type State = ReturnType<typeof state>
